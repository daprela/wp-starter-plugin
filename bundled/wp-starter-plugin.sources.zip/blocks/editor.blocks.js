/**
 * Import internationalization
 */
import "./i18n.js";

/**
 * Import registerBlockType blocks
 */
import "./demo/";
