<?php

namespace dapre_wpsp\includes;

/**
 * Define the utility functions that don't belong to any class.
 *
 *
 * @link       https://giuliodaprela.com
 * @since      1.0.0
 *
 * @package    dapre_wpsp
 * @subpackage dapre_wpsp/includes
 */