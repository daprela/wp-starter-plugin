<?php

namespace DapreWpsp\Includes;

/**
 * Define the utility functions that don't belong to any class.
 *
 *
 * @link       https://giuliodaprela.com
 * @since      1.0.0
 *
 * @package    DapreWpsp
 * @subpackage DapreWpsp\Includes
 */